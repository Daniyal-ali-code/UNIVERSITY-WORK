#include<iostream>
using namespace std;

void greet() {
	cout << "Hello!" << endl;
	return;
}

int main () {
	greet ();
	
	return 0;
}

