package Q1;

public class main {

	    public static void main(String[] args) {
	        Car myCar = new Car();
	        myCar.brand = "Toyota";
	        myCar.startEngine();  // from Vehicle
	        myCar.honk();         // from Car
	    }
	}
