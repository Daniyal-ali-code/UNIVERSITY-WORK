/**
 * 
 */
/**
 * 
 */
module JavaSwingLabTask {
	requires java.desktop;
}