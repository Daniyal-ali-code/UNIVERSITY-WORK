package Question3;

public class Main {
    public static void main(String[] args) {
        Stackk stack = new Stackk();

        stack.pushBooks();
        stack.popBooks();
        stack.showBooks();
    }
}
