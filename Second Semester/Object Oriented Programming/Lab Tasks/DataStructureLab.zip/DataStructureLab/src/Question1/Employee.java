package Question1;
import java.util.ArrayList;
public class Employee {
	int iD;
	String name ; 
	double salary ; 
		
	Employee(int i , String e , double s){
		iD = i ; 
		name = e ; 
		salary = s ;
	}
	
}
