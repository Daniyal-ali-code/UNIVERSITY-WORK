/**
 * 
 */
/**
 * 
 */
module Lab_1 {
}