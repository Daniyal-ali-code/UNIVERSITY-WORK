package lab;

public class Rectangle {
	double length=45.5;
	double width=58.45;
	
	double calculatearea() {
		return length*width;
		
	}
}
