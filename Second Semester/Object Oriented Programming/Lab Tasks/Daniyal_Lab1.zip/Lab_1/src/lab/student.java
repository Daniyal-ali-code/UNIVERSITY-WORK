package lab;

public class student {
	String name ="ray";
	double marks = 51;
	
	void checkpass() {
		if(marks>=50) {
			System.out.println("PASS");
		}else {
			System.out.println("FAILED");
		}
	}

}
