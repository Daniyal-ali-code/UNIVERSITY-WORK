package lab;

public class calculator {
	int add(int a,int b) {
		return a+b;
	}
	
	int multiply(int c,int d) {
		return c*d;
	}

}
