package P1Q2;

public class Main {

	public static void main(String[] args) {
		        NumberGenerator generator = new NumberGenerator();

		       
		        generator.printNumbers();
		    }

	}


