package P1Q4;

public class Main {

	public static void main(String[] args) {
		        AbsoluteDifferenceCalculator calculator = new AbsoluteDifferenceCalculator();

		        calculator.calculateAbsoluteDifference();
		    }
	}


