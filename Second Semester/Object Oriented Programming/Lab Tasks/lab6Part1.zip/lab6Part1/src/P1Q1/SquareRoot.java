package P1Q1;

public class SquareRoot {
	    public double findSquareRoot(double number) {
	        return Math.sqrt(number);
	    }
	}


