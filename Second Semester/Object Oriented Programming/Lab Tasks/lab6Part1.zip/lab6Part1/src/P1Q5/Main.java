package P1Q5;

public class Main {

	public static void main(String[] args) {
	
		        LargestNumberFinder finder = new LargestNumberFinder();

		        finder.findLargestNumber();
		    }
	}

