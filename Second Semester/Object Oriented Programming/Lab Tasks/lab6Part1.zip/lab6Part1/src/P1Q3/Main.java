package P1Q3;

public class Main {

	public static void main(String[] args) {
		
		        PowerCalculator calculator = new PowerCalculator();

	
		        calculator.calculatePower();
		    }
	}

