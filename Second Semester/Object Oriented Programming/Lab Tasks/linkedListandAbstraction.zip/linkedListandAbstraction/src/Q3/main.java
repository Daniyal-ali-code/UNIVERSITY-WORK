package Q3;
import java.util.Collections;
import java.util.LinkedList;


		public class main {
		    public static void main(String[] args) {
		        LinkedList<String> node = new LinkedList<String>();
		        
		       for (int i = 0; i <= 10; i++) {
		            node.add(String.valueOf(i));
		        }

		   
		        node.addFirst("First Number");
		        node.addLast("Last Number");

		        System.out.println("Original List:");
		        System.out.println(node);

		        Collections.reverse(node);

		        System.out.println("Reversed List:");
		        System.out.println(node);
	}

}
