package Q3;

public class Main {

	public static void main(String[] args) {
		CountdownTimer cT = new CountdownTimer();
		cT.start();

	}

}
