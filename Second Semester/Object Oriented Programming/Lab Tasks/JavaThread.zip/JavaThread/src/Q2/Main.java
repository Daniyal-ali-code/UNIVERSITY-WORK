package Q2;

public class Main {

	public static void main(String[] args) {
		NumberPrinter nP = new NumberPrinter ();
		CharacterPrinter cP = new CharacterPrinter();
		nP.start();
		cP.start();
	}

}
