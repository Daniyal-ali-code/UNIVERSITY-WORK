package Q1;

public class Main {

	public static void main(String[] args) {
		simplePrinter sP = new simplePrinter();
		sP.start();

	}

}
