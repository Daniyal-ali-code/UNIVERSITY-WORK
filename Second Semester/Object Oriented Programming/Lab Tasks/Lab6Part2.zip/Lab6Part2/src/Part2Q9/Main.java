package Part2Q9;

public class Main {
    public static void main(String[] args) {
        Array A4 = new Array();
        A4.printEvenNumbers();
    }
}