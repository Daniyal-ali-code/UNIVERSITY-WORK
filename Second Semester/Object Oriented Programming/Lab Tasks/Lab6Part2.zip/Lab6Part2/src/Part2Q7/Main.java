package Part2Q7;

public class Main {

	public static void main(String[] args) {
        Array A2 = new Array();
        int max = A2.findMax();
        System.out.println("The maximum element is: " + max);
    }
}
