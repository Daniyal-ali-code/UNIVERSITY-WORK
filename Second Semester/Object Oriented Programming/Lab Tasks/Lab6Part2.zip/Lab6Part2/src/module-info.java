/**
 * 
 */
/**
 * 
 */
module Lab6 {
}