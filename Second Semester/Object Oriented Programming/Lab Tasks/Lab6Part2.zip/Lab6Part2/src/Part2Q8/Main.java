package Part2Q8;

public class Main {
    public static void main(String[] args) {
        Array A3 = new Array();
        A3.printReverse();
    }
}
