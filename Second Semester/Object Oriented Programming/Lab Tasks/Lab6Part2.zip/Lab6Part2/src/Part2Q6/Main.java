package Part2Q6;

public class Main {

	public static void main(String[] args) {
        Array A1 = new Array();
        int total = A1.calculateSum();
        System.out.println("The sum of the array is: " + total);
    }
}