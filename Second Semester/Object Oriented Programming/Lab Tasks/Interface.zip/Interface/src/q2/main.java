package q2;

public class main {

	public static void main(String[] args) {
		
		printable print1 = new book();
		print1.print();
		printable print2 = new magazine();
		print2.print();
	}

}
